

import fatec.poo.model.FuncionarioComissionado;
import fatec.poo.model.FuncionarioHorista;
import fatec.poo.model.FuncionarioMensalista;

/**
 * @author Carolina
 */
public class Aplic {

    public static void main(String[] args) {
        
       // instanciação de um objeto (funcHor), da classe FuncionarioHorista 
        FuncionarioHorista funcHor = new FuncionarioHorista(1010,
                                                            "Pedro Silveira",
                                                            "14/05/1978",
                                                            15.80);
        
        FuncionarioMensalista funcMen = new FuncionarioMensalista(2020,
                                                                  "Ana Beatriz", 
                                                                  "22/10/1997",
                                                                  600.0);
        
        FuncionarioComissionado funcCom = new FuncionarioComissionado(3030,
                                                                  "Carla Ribeiro", 
                                                                  "15/04/1998",
                                                                  0.05);
        
        
        funcHor.setQtdeHorTrab(90);
        funcHor.setCargo("Programador");
        System.out.println(" Registro: " + funcHor.getRegistro());
        System.out.println(" Nome: " + funcHor.getNome());
        System.out.println(" Data de Admissão: " + funcHor.getDtAdmissao());
       System.out.println("Cargo: " + funcHor.getCargo());
        System.out.println("Salário Bruto   => " + funcHor.calcSalBruto());
        System.out.println("Desconto        => " + funcHor.calcDesconto());  
       System.out.println("Gratificação    => " + funcHor.calcGratificacao());
        System.out.println("Salário Líquido => " + funcHor.calcSalLiquido());
        
        
        funcMen.setNumSalMin(2.5);
        funcMen.setCargo("Auxiliar Administrativo");
         System.out.println("\n Registro: " + funcMen.getRegistro());
        System.out.println(" Nome: " + funcMen.getNome());
        System.out.println(" Data de Admissão: " + funcMen.getDtAdmissao());
        System.out.println("Cargo: " + funcMen.getCargo());
         System.out.println(" Salário Bruto   => " + funcMen.calcSalBruto());
        System.out.println("Desconto        => " + funcMen.calcDesconto());        
        System.out.println("Salário Liquido => " + funcMen.calcSalLiquido());
        
        
        funcCom.setSalBase(500.00);
        funcCom.setAddVenda(10);
        
        
        funcCom.setCargo("Vendedor");
         System.out.println("\n Registro: " + funcCom.getRegistro());
        System.out.println(" Nome: " + funcCom.getNome());
        System.out.println(" Data de Admissão: " + funcCom.getDtAdmissao());
        System.out.println("Cargo: " + funcCom.getCargo());
         System.out.println(" Salário Bruto   => " + funcCom.calcSalBruto());
        System.out.println("Desconto        => " + funcCom.calcDesconto()); 
        System.out.println("Gratificação    => " + funcCom.calcGratificacao());

        System.out.println("Salário Liquido => " + funcCom.calcSalLiquido());
    }
    
    
    
}
