
package fatec.poo.model;

/**
 *
 * @author Carolina
 */

// Extends estabelece o vinculo de herança, 
//entre a SuperClasse func e a subClasse FuncionarioHorista
public class FuncionarioHorista  extends Funcionario {
    
    
    private double valHorTrab;
    private int qtdeHorTrab;
    
    public FuncionarioHorista( int r, String n, String dtAdm, double vht){
        
        super(r,n,dtAdm); // chama o metodo construtor da superclasse funcionario
        valHorTrab = vht;
        
    }
    
    public  void setQtdeHorTrab( int qht){
        qtdeHorTrab = qht;
        
        
    }
    
    /* Aplicando o Poliformismo,
    
       * Aqui a classe não somente herdou o método, 
       * como tbm pôde modificá -lo diante suas necessidades
    ** Sobreposição(override) de métodos
    
    */ 
    //Implementação da operação Calculo do Salário Bruto 
    public double calcSalBruto(){
        return( valHorTrab * qtdeHorTrab);
    }
    
    public double calcGratificacao(){
        return(calcSalBruto() * 0.075);
    }
    
    public double calcSalLiquido(){
        
        return(calcSalBruto() + calcGratificacao() - calcDesconto());
    }
    
}
