/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fatec.poo.model;

/**
 *
 * @author 0030482323038
 */
public class FuncionarioComissionado extends Funcionario {
    
    
        private  double salBase;
        private  double taxaComissao;
        private double totalVendas; 
        
      public FuncionarioComissionado(int r, String n, String dtAdm, double Txc){
        super(r, n, dtAdm);
         taxaComissao = Txc;
        
      }
        
      
     public void setSalBase( double SalB){
         
         
     }
        public double calcSalBruto(){
     return(taxaComissao * totalVendas + (salBase));  
    }
    
}
