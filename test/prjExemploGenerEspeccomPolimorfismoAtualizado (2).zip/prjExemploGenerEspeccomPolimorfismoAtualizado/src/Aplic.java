import fatec.poo.model.FuncionarioHorista;
import fatec.poo.model.FuncionarioMensalista;

/**
 *
 * @author Fatec
 */
public class Aplic {
    public static void main(String[] args) {
        FuncionarioHorista funcHor = new FuncionarioHorista(1010,
                                                            "Pedro Silveira",
                                                            "14/05/1978",
                                                            15.80);
        
        FuncionarioMensalista funcMen = new FuncionarioMensalista(2020,
                                                                  "Ana Beatriz", 
                                                                  "22/10/1997",
                                                                  600.0);
        
        funcHor.setQtdeHorTrab(90);  
        funcHor.setCargo("Programador");
        
        System.out.println("Registro: " + funcHor.getRegistro());
        System.out.println("Nome: " + funcHor.getNome());
        System.out.println("Data Admissão: " + funcHor.getDtAdmissao());
        System.out.println("Cargo: " + funcHor.getCargo());
        System.out.println("Salário Bruto   => " + funcHor.calcSalBruto());
        System.out.println("Desconto        => " + funcHor.calcDesconto());  
        System.out.println("Gratificação    => " + funcHor.calcGratificacao());
        System.out.println("Salário Líquido => " + funcHor.calcSalLiquido());
        
        funcMen.setNumSalMin(2.5);
        funcMen.setCargo("Aux. Administrativo");
        System.out.println("\n\nRegistro: " + funcMen.getRegistro());
        System.out.println("Nome: " + funcMen.getNome());
        System.out.println("Data Admissão: " + funcMen.getDtAdmissao());
        System.out.println("Cargo: " + funcMen.getCargo());
        System.out.println("Salário Bruto   => " + funcMen.calcSalBruto());
        System.out.println("Desconto        => " + funcMen.calcDesconto());        
        System.out.println("Salário Liquido => " + funcMen.calcSalLiquido());
    }    
}
