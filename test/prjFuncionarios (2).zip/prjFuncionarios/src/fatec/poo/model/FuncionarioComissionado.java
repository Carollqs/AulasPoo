
package fatec.poo.model;

/**
 *
 * @author Carolina
 */
public class FuncionarioComissionado extends Funcionario {
    
     private double salBase;
     private double taxaComissao;
     private double totalVendas;
     
     
      public FuncionarioComissionado(int r, String n, String dtAdm, double txc){
          super(r,n,dtAdm);
          taxaComissao = txc;
      }
      
      
      public  void setSalBase( double slb){
          
          salBase = slb;
      }
      
      public double getSalBase(){
          return(salBase);
      }
      
      public double getTotalVendas(){
       return(totalVendas);   
      }
    public double getTaxaComissao(){
    
    return(taxaComissao);
    }
    
    public void  addVenda( int v){
        totalVendas += v;
    } 
    public double calcSalBruto(){
     return( salBase + (totalVendas/100 * taxaComissao ));
    }
    
    public double calcGratificacao(){
        
        if (totalVendas <= 5.000){
            
        return( calcSalBruto());
        } 
        else if( totalVendas > 5.000 || totalVendas < 10.000){
       
        return( (calcSalBruto() * 0.03) + calcSalBruto());
       }  else 
            return( (calcSalBruto() * 0.05) + calcSalBruto());
                
    
    }
     public double calcSalLiquido(){
         
         return( super.calcSalLiquido() + calcGratificacao());
     }
}
