
/**
 *
 * @author Carolina
 */
public  class PessoaFisica  extends Pessoa{
    
    
    private String cpf;
    private double base;
 
    
    public PessoaFisica( String n, int anoIn,  int anoA, String Cp){
    
     super (n, anoIn, anoA);
     
     cpf = Cp;
    }
    
     public  double calcBonus( int anoInscricao){
  
          /*if( totalCompras > 12.000) {
          
           return((anoAtual - anoInscricao) * base);
         }
         */
            return 0;
         // return(anoAtual);


     }
     
    
     public String getCpf(){
      
         return(cpf);
     
     }
    
     
     public void setBase(double b){
     
      base = b;
     }
     
     public double getBase(){
     
     return(base);
     }
}
