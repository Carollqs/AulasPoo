
/*
 * @author Carolina
 */
public abstract  class Pessoa {
    
    private String nome;
    private int anoInscricao;
    private double totalCompras;
       private int anoAtual;
    
    
    public Pessoa(String n, int anoIn, int anoA){
    
    nome = n;
    anoInscricao = anoIn;
    
    anoAtual = anoA;
    }
    
       
  
    abstract public double calcBonus( int anoInscricao );
  
     
   

   public void  addCompras(double valCompra){
       
       totalCompras += valCompra;
   
   }
   
    public double getTotalCompras(){
   
   return(totalCompras);
   
   }
   
   public  String getNome(){
   
   return(nome);
   }
   
   public int  getAnoInscricao(){
        return(anoInscricao);
   
   }
   
   
}
