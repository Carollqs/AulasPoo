
/**
 *
 * @author Carolina
 */
public class Aplic {

    
    public static void main(String[] args) {

  
        PessoaFisica PesFis = new PessoaFisica( "Alberto Freitas",
                2010,
                2020, 
                "0909090909");
        
        
        
        //Anotar essa instanciação no caderdo e suas regras, cai na  prova 
        PessoaJuridica PesJur = new PessoaJuridica( "Clara Nunes", 2005, 2018, "3456789010");
        
        
        
        
       


    }
    
}
